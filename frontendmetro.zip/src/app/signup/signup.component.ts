import { Component } from '@angular/core';
import { User } from '../model/user';
import { UserService } from '../service/user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-signup',
  standalone: false,
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css'] // Fixed typo
})
export class SignupComponent {
  user = new User(0, "", "", "", "", "", "");

  constructor(private userService: UserService, private router: Router) {}

  onSubmit() {
    if (this.validateForm()) {
      this.userService.userSignUp(this.user).subscribe(
        (response) => {
          console.log(response);
          alert("User signup successful!");
          this.router.navigate(['usersigninUrl']);
        },
        (error) => {
          console.error('Error during signup:', error);
          alert('Something went wrong. Please try again.');
        }
      );
    } else {
      alert('Please fill out all required fields correctly.');
    }
  }

  Onback() {
    this.router.navigate(['welcomepageurl']);
  }

  private validateForm(): boolean {
    const { username, userPassword, phone, emailId, city, role } = this.user;
    return (
      !!username.trim() && // Convert to boolean
      !!userPassword.trim() && // Convert to boolean
      userPassword.length >= 6 &&
      !!phone.trim() && // Convert to boolean
      /^\d{10}$/.test(phone) &&
      !!emailId.trim() && // Convert to boolean
      /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailId) &&
      !!city.trim() && // Convert to boolean
      !!role.trim() // Convert to boolean
    );
  }

}
