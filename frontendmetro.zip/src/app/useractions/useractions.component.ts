import { Component } from '@angular/core';

@Component({
  selector: 'app-useractions',
  standalone: false,
  
  templateUrl: './useractions.component.html',
  styleUrl: './useractions.component.css'
})
export class UseractionsComponent {

  
}
