import { Component } from '@angular/core';
import { UserService } from '../service/user.service';
import { User } from '../model/user';
import { Router } from '@angular/router';
@Component({
  selector: 'app-login',
  standalone: false,
  
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
user=new User(0,"","","","","","");
userId:any;
constructor(private userService:UserService,
  private router:Router
){

}
  onSubmit()
  {
      this.userService.userSignIn(this.user).subscribe(
        (response:any) => {
          console.log(response);
          if(response!=null)
          {
            this.user=response;
            this.userId=this.user.userId;
            if(this.user.role=="Admin")
            {

              this.router.navigate(['adminhomeurl',this.userId]);
            }
            else if(this.user.role=="User")
            {
              this.router.navigate(['userhomeurl',this.userId]);
            }
          
          }else
          alert("User details not found!!")
        }
      );

  }
  Onback(){
    this.router.navigate(['welcomepageurl']);
  }
  userPage()
  {
    this.router.navigate(['useractionurl']);
  }
}
