import { Component } from '@angular/core';
import { OnInit } from '@angular/core';
import { UserService } from '../service/user.service';
import { CardService } from '../service/card.service';
import { Card } from '../model/card';
import { Router } from '@angular/router';
@Component({
  selector: 'app-viewcards',
  standalone: false,
  
  templateUrl: './viewcards.component.html',
  styleUrl: './viewcards.component.css'
})
export class ViewcardsComponent implements OnInit {
  constructor(private cardService:CardService,private router:Router){

  }
  cardDetails:any;
  cardList:any
  card=new Card(0,"",0,new Date(),new Date());
count=5;
p=1;
  ngOnInit(): void {
    this.cardList = 
      this.cardService.getCards().subscribe(
        (data:any) => {
          this.cardList = data;
        }
      )

  }
activeCard(cardId:any){
  this.cardService.updateActiveCardStatus(cardId,this.card).subscribe(
    (data:any) => {
      alert("Card is active");
    }
  )
}
inActiveCard(cardId:any){
  this.cardService.updateInActiveCardStatus(cardId,this.card).subscribe(
    (data:any) => {
      alert("Card is InActive");
    }
  )
}

Onback(){
  this.router.navigate(['adminhomeurl']);
}

}
