import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from '../service/user.service';

@Component({
  selector: 'app-updateuser',
  standalone: false,
  
  templateUrl: './updateuser.component.html',
  styleUrl: './updateuser.component.css'
})
export class UpdateuserComponent implements OnInit{
  userId:any;
  user:any;
constructor(private activatedRoute:ActivatedRoute,
  private userService:UserService,
  private router:Router

)
{

  
}
  ngOnInit(): void {
    this.userId=this.activatedRoute.snapshot.params['userId'];
    this.userService.getUserById(this.userId).subscribe((data:any)=>{

this.user=data;
  });
    
  }
  onSubmit(){
    this.userService.updateUser(this.userId,this.user).subscribe(
      (data:any)=>{
        alert("Data Updated successfully");
        this.router.navigate(['viewusersUrl']);
  });
  }

}
