import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from '../service/user.service';
import { OnInit } from '@angular/core';
@Component({
  selector: 'app-adminhome',
  standalone: false,
  
  templateUrl: './adminhome.component.html',
  styleUrl: './adminhome.component.css'
})
export class AdminhomeComponent implements OnInit {
  username:any;
  userId:any;
  user:any;
constructor(private router:Router,private userService:UserService,private activatedRoute:ActivatedRoute){

}
ngOnInit(): void {
  this.userId=this.activatedRoute.snapshot.params['userId'];
  this.userService.getUserById(this.userId).subscribe(
    (response:any)=>{
      this.user=response;
      this.username=this.user.username;
    }
  )
}
onSubmit()
{
  
}
getAllUsers(){
  this.router.navigate(['viewusersUrl']);//It navigates to app-routing.module.ts
}
viewAllCards(){
  this.router.navigate(['viewcardsurl']);//It navigates to app-routing.module.ts
}
  Onback(){
    this.router.navigate(['usersigninUrl']);
  }
}
