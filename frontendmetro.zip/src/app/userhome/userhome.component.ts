import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from '../service/user.service';
import { Card } from '../model/card';
import { CardService } from '../service/card.service';

@Component({
  selector: 'app-userhome',
  standalone: false,
  templateUrl: './userhome.component.html',
  styleUrls: ['./userhome.component.css']
})
export class UserhomeComponent implements OnInit {
  cardId: any;
  userId: any;
  user: any;
  username: any;
  recharge: boolean = false;
  status:any;
  ramount: any;
  cardDetails: any;
  detailsBlock: boolean = false;
  paymentType: string = ''; // Holds the selected payment type
  card = new Card(0, "", 0, new Date(), new Date());
  upiId: string = ''; // For UPI input
  cardDetailsInput: string = ''; // For card details input
  isCardValid: boolean = true;
isCvvValid: boolean = true;
isDateValid: boolean = true;
bank = {
  cCardnumber: '',
  cCvvnumber: '',
  expiryDate: ''
};


  constructor(
    private activatedRoute: ActivatedRoute,
    private userService: UserService,
    private cardService: CardService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.userId = this.activatedRoute.snapshot.params['userId'];
    this.userService.getUserById(this.userId).subscribe((response: any) => {
      this.user = response;
      this.username = this.user.username;
    });
  }

  getCard() {
    this.recharge = false;
    this.detailsBlock = false;
    this.cardService.getCard(this.userId).subscribe((response: any) => {
      if (response != null) {
        alert("This user already has a card and cannot generate another one.");
      } else {
        this.cardService.addCard(this.card, this.userId).subscribe((response: any) => {
          alert("Card created successfully!!");
        });
      }
    });
  }

  rechargeCard() {
    this.detailsBlock = false;
    this.recharge = true;
    this.paymentType = ''; // Reset the payment type
    console.log('Recharge Card');
  }

  rechargeCard1() {
    // Validate the amount
    if (this.ramount <= 0) {
      alert('Please enter a valid amount.');
      return; // Exit if the amount is invalid
    }
  
    if (this.paymentType === 'cash') {
      // Cash Payment Logic
      console.log('Recharging with cash:', this.ramount);
      this.cardService.updateRecharge(this.ramount, this.userId, this.card).subscribe((response: any) => {
        alert('Recharge successful!!');
      });
  
    } else if (this.paymentType === 'upi' ) {
      // UPI Payment Logic
      if (!this.upiId.trim()) {
        alert('Please enter a valid UPI ID.or check if the card is active');
        return;
      }
      console.log('Recharging with UPI ID:', this.upiId, 'Amount:', this.ramount);
      this.cardService.updateRecharge(this.ramount, this.userId, this.card).subscribe((response: any) => {
        alert('Recharge successful!!');
      });
  
    } else if (this.paymentType === 'cards' && ) {
      // Card Payment Logic
      if (!this.isCardValid || !this.isCvvValid || !this.isDateValid) {
        alert('Please enter valid card details or check if the card is active');
        return;
      }
      console.log('Recharging with Card Details:', this.bank, 'Amount:', this.ramount);
      this.cardService.updateRecharge(this.ramount, this.userId, this.card).subscribe((response: any) => {
        alert('Recharge successful!!');
      });
  
    } else {
      // No Payment Type Selected
      alert('Please select a valid payment option or check if the card is active');
    }
  }
  

  getCardDetails() {
    this.recharge = false;
    this.cardService.getCardsById(this.userId).subscribe((response: any) => {
      this.detailsBlock = true;
      this.cardDetails = response;
      console.log(this.cardDetails);
    });
  }

  logout() {
    this.router.navigate(['usersigninUrl']);
  }

  // Method to handle the selection of payment type
  cardType(event: Event): void {
    this.paymentType = (event.target as HTMLSelectElement).value;
    console.log('Selected payment type:', this.paymentType);
  }
  onSubmit()
  {
    console.log('Form submitted');
  }
  // Validate Card Number
checkcards(event: Event): void {
  const cardNumber = (event.target as HTMLInputElement).value;
  this.isCardValid = cardNumber.length === 16 && /^[0-9]+$/.test(cardNumber);
}

// Validate CVV
checkcvv(event: Event): void {
  const cvv = (event.target as HTMLInputElement).value;
  this.isCvvValid = cvv.length === 3 && /^[0-9]+$/.test(cvv);
}

// Validate Expiry Date
checkdate(event: Event): void {
  const expiryDate = new Date((event.target as HTMLInputElement).value);
  const today = new Date();
  this.isDateValid = expiryDate > today;
  
}

}
