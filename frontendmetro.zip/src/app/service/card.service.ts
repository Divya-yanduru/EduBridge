import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CardService {

  constructor(private http:HttpClient) { }
url="http://localhost:8089/api/cards"
  addCard(card:any,userId:any){
    console.log(card);
    console.log(userId);
    return this.http.post(`${this.url}/${userId}`,card);
  }
updateRecharge(ramount:any,userId:any,card:any){
  return this.http.put(`${this.url}/${userId}/${ramount}`,card);
}
getCards(){
  return this.http.get(`${this.url}`);
}
updateActiveCardStatus(cardId:any,card:any){
  return this.http.put(`${this.url}/active/${cardId}`,card);
}
updateInActiveCardStatus(cardId:any,card:any){
  return this.http.put(`${this.url}/inactive/${cardId}`,card);
}
getCardsById(userId:any){
  return this.http.get(`${this.url}/getcardsbyuserid/${userId}`);
}
getCard(userId:any){
  return this.http.get(`${this.url}/getcardsbyuserid/${userId}`);
}

}
