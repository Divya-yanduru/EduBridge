import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http:HttpClient) { }
    
   url="http://localhost:8089/users";

    userSignUp(user:any)
   {
    return this.http.post(`${this.url}`,user);

   }
   getAllUsers()
   {
    return this.http.get(`${this.url}`);
   }
   deleteUser(userId:any)
   {
    return this.http.delete(`${this.url}/${userId}`);//RestApi endpoint
   }
   getUserById(userId:any)
   {
    return this.http.get(`${this.url}/userId/${userId}`);
   }
   updateUser(userId:any,user:any)
   {
    return this.http.put(`${this.url}/${userId}`,user);
    
   }
   userSignIn(user:any)
   {
    return this.http.post(`${this.url}/login`,user);

   }
   search(searchText:any)
   {
    return this.http.get(`${this.url}/searchusers/${searchText}`);
   }
   
}
